This folder contains all related python source codes that was used to complete the EB5103 Data Analytics workshop on 
predicting bike sharing demand. The material here can be used to replicate the results that are highlighted in the 
accompanying report. Below are some useful information to note.

#### Python Environment and Installations used to run these codes
1. Python 3
2. Sklean
3. Pandas
4. Tensorflow-keras
5. Matplotlib

#### How to run:
python3 process/Process.py
to examine individual models detailed in the report, input model name using the following terms 
1. nn		- Neural Network Model 
2. rf		- Random Forest
3. xgb		- XGBoost
4. blend	- Ensemble (Blending)
5. stacking	- Ensemble (Stacking)

#### Folder Structure / Description
1. dataset folder 	� Contains original dataset. Day.csv was used as input for the various models
2. model folder 	� Contains the respective python codes for the models mentioned above. Do note that 
			Ensemble(Blending) is included as part of Process.py (see process folder below) as 
			it is a straightforward process.
3. model_saved folder 	� contains the optimal models for Random Forest, Neural Network and XGBoost
4. process folder 	� contains python scripts for data loading  and pre-processing.
5. Profit folder 	� contains python script to conduct business analysis for the assignment
6. Util folder 		� contains some figures that were used in the report.

#### The complete set of python source code can also be found at (https://github.com/alex44jzy/nus-bikesharing). 
For further clarifications, kindly approach the team.
